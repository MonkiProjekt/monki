<?php
session_start();
if (isset ( $_SESSION ['jrkn'] ) && isset ( $_GET ['id'] )) {
	include 'c.php';
	$id = $_GET ['id'];
	$kontroll = mysqli_query ( $con, "UPDATE emails SET state='10' WHERE id='$id'" ) or die(mysqli_error($con));
	die("success");
}
?>
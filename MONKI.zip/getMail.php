<?php
session_start();

if (isset ( $_SESSION ['jrkn'] )) {
	error_reporting(E_ALL & ~E_NOTICE);
	include 'planc.php';
	include 'c.php';
	
	$kasutaja = $_SESSION ['jrkn'];
	
	//Näita meile:
	$query = mysqli_query($con,"SELECT * FROM emails WHERE assigned='0' AND state !='10' ORDER BY date DESC") or die(mysqli_error($con));
		
		
		
		
	//Näita päist
	echo '
		<thead>
            <tr>
                <th>Aeg</th>
                <th>Saatja</th>
                <th>Teemarida</th>
				<th>Valikud</th>
            </tr>
        </thead>
		<tbody>
	';
	
	while($array = mysqli_fetch_array($query)){
		$id = $array[0];
		$kellelt = $array[1];
		$teema = $array[2];
		$kuup2ev = $array[3];
		
		echo "
		
		<tr onclick='preview($id)'>
            <td>$kuup2ev</td>
            <td>$kellelt</td>
            <td>$teema</td>
            <td>
				<a href='#' onclick='window.location=\"/meilid/$id.eml\"'>Avan</a>
				<a href='#' onclick='take($id)'>Võtan</a>
				<a href='#' onclick='spam($id)'>Spam</a>
			</td>
        </tr>
		
		";
		
	}
	echo '</tbody>';
}
?>
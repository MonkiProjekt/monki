<?php
session_start();
if (isset ( $_SESSION ['jrkn'] ) && isset ( $_GET ['id'] )) {
	include 'c.php';
	$id = $_GET ['id'];
	$uid = $_SESSION ['jrkn'];
	$kontroll = mysqli_query ( $con, "UPDATE emails SET assigned='$uid',state='1' WHERE id='$id'" ) or die(mysqli_error($con));
	die("success");
}
?>
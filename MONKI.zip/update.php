<?php
session_start();
if (isset ( $_SESSION ['jrkn'] ) && isset ( $_GET ['id'] ) && isset ( $_GET ['state'] )) {
	include 'c.php';
	$id = $_GET ['id'];
	$state = $_GET ['state'];
	$kontroll = mysqli_query ( $con, "UPDATE emails SET state='$state' WHERE id='$id'" ) or die(mysqli_error($con));
	die("success");
}
?>
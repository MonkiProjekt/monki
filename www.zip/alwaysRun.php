<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
<?php

error_reporting(E_ALL & ~E_NOTICE);
include 'planc.php';
include 'c.php';

$server = "{imap.gmail.com:993/imap/ssl/novalidate-cert}";
$username = "Vanameez007@gmail.com";
$password = "angimkuwijxqqdus";
$mbox = imap_open ( $server, $username, $password ) or die ( imap_last_error () );
$message_count = imap_num_msg($mbox);

	//Kui on meile, siis uuenda neid:
		
if ($message_count > 0) {
			
	$i = 1;
	
	//DEBUG: echo "Meile peab olema $message_count tükki!";
			
	while($i <= $message_count){
				
		//VÕTAME MEILI ETTE
		$headers = imap_fetchheader($mbox, $i, FT_PREFETCHTEXT);
				
		//ANNAME MEILIE NIME
		$stamp = time().rand(0,999);
		$name = $stamp.".eml";
				
		//SALVESTAME MEILI KATALOOGI
		file_put_contents("./meilid/".$name, $headers . "\n" . imap_body($mbox, $i)) or die();
				
		//ANNAME MEILI PROGRAMMILE
		$emailParser = new PlancakeEmailParser(file_get_contents("./meilid/".$name));
		
		//KONTROLLIME, KAS ON MANUS
		$bodycheck = urlencode($emailParser->getHTMLBody());


				//KUI ON, LÕIKAME VÄLJA
				if (strpos($bodycheck, 'Content-Disposition') !== false) {
					$arr = explode("Content-Disposition", $bodycheck, 2);
					$body = $arr[0];
					$subjecta = $emailParser->getSubject();
					$subject = '✉ ' . $subjecta;
				} else {
					$body = $bodycheck;
					$subject = $emailParser->getSubject();
				}

		//$body = imap_qprint(imap_fetchbody($inbox,$email_number,2));

				
		$header = imap_headerinfo ( $mbox, $i );
		$from = $header->from;
		
		foreach ( $from as $id => $object ) {
			$fromaddress = $object->mailbox . "@" . $object->host;
		}
				
		$kuup = $header->date;
		$arr = explode(":",$kuup);
		$date = $arr[0].":".$arr[1];
				
		$txt = "INSERT INTO emails (id, fromaddress, subject, date, body, assigned, state) VALUES ('$stamp', '$fromaddress', '$subject', '$date', '$body', '0', '0')";

		$query = mysqli_query($con,$txt) or die(mysqli_error($con));
		imap_delete($mbox,$i);
		$i++;
	}
}
imap_close($mbox);

echo "";
echo "<h1>Meilid edukalt laetud!</h1>";

echo "<meta http-equiv='refresh' content='10;url=http://192.168.1.101/alwaysRun.php'>";
?>
  <title>BANAAN</title>
 
</head>

<body>


</body>
</html>